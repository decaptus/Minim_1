package edu.upc.dsa;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;

public class EjemploManagerTest {
    @Before
    public void setUp() {
        EjemploManagerImpl.getInstance().addBrote("Brote1");
        EjemploManagerImpl.getInstance().addBrote("Brote2");
        EjemploManagerImpl.getInstance().addBrote("Brote3");
        EjemploManagerImpl.getInstance().addBrote("Brote4");
        EjemploManagerImpl.getInstance().afegirCaso("Kevin","Garcia","Caso1",new Date (1996,9,2),new Date(2020,6,24),"nocaso","Femenino","kevinalca@gmail","635473","dsfasd","Brote1");
        EjemploManagerImpl.getInstance().afegirCaso("Joel","Garcia","Caso1",new Date (1996,9,2),new Date(2020,6,24),"nocaso","Femenino","kevinalca@gmail","635473","dsfasd","Brote1");



    }



    @Test
    public void CrearBrote() {


        EjemploManagerImpl.getInstance().addBrote("Brote5");
        assertEquals(5, EjemploManagerImpl.getInstance().sizeBrotes());

    }

    @Test
    public void AñadirCaso() {


        EjemploManagerImpl.getInstance().afegirCaso("Majo","Garcia","Caso1",new Date (1996,9,2),new Date(2020,6,24),"nocaso","Femenino","kevinalca@gmail","635473","dsfasd","Brote1");

        assertEquals(3, EjemploManagerImpl.getInstance().sizeCasos());

    }


    @After
    public void tearDown() { EjemploManagerImpl.getInstance().delete();}







}

package edu.upc.dsa.models;

public class Muestra {
    //un identificador que lo identifica unívocamente, un
    //identificador del clínico que ha extraído la muestra, un identificador de la persona
    //y la fecha de extracción y el identificador del laboratorio a enviar

    String id;
    String clinico;
    String user;
    String fecha;
    String lab;

    public Muestra(String id, String clinico, String user, String fecha, String lab) {
        this.id = id;
        this.clinico = clinico;
        this.user = user;
        this.fecha = fecha;
        this.lab = lab;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClinico() {
        return clinico;
    }

    public void setClinico(String clinico) {
        this.clinico = clinico;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getLab() {
        return lab;
    }

    public void setLab(String lab) {
        this.lab = lab;
    }
}

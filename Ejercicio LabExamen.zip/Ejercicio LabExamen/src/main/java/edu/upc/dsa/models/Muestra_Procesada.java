package edu.upc.dsa.models;

public class Muestra_Procesada {
    String id;
    String clinico;
    String user;
    String fecha;
    String lab;
    String comentario;
    String resultado;

    public Muestra_Procesada(String id, String clinico) {
        this.id = id;
        this.clinico = clinico;
        this.user = user;
        this.fecha = fecha;
        this.lab = lab;
        this.comentario = comentario;
        this.resultado = resultado;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClinico() {
        return clinico;
    }

    public void setClinico(String clinico) {
        this.clinico = clinico;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getLab() {
        return lab;
    }

    public void setLab(String lab) {
        this.lab = lab;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}

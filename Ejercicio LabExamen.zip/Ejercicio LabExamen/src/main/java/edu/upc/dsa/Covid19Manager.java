package edu.upc.dsa;

import edu.upc.dsa.models.Muestra;

import java.util.*;

public interface Covid19Manager {

    //Crear una persona en el sistema
    public void addPersona (String id, String nombre, String apellidos, String edad, String valoracion);

    //Crear un laboratorio
    public void addLab (String id);

    //Extraer muestra
    public void ExtraerMuestra (String id, String idClinica, String idUsuario, String date, String lab);

    //Listado de las muestras de un usuario
    public List<Muestra> findAll();

    //Procesar muestras
    public void ProcesarMuestra (String resultado, String comentario);

    //Gets

}

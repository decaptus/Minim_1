package edu.upc.dsa.models;

import java.util.Queue;
import edu.upc.dsa.models.Muestra;

public class Lab {
    Queue<Muestra> muestras;
    String id;

    public Lab(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void addMuestra(Muestra m){
        this.muestras.add(m);
    }
}

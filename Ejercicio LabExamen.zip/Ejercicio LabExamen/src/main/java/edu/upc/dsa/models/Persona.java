package edu.upc.dsa.models;

import java.util.List;
import edu.upc.dsa.util.RandomUtils;


public class Persona {
    // identificador,
    //nombre y apellidos, fecha de nacimiento (o edad) y una valoración del nivel de
    //salud de la persona (A, B, C, D) siendo ‘A’ el nivel de enfermedad menos
    //avanzada y D el nivel de enfermedad más avanzada

    String nombre;
    String apellidos;
    String edad;
    String valoracion;

    List<Muestra_Procesada> muestras_procesadas;

    public List<Muestra_Procesada> getMuestras_procesadas() {
        return muestras_procesadas;
    }

    public void setMuestras_procesadas(List<Muestra_Procesada> muestras_procesadas) {
        this.muestras_procesadas = muestras_procesadas;
    }

    public Persona(String nombre, String apellidos, String edad, String valoracion) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.valoracion = valoracion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getValoracion() {
        return valoracion;
    }

    public void setValoracion(String valoracion) {
        this.valoracion = valoracion;
    }

    //Añadimos una muestra a nuestra lista de muestras
    public void addMuestra (Muestra_Procesada mp){
        this.muestras_procesadas.add(mp);
    }
}

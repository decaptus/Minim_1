package edu.upc.dsa;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import edu.upc.dsa.models.Muestra;
import edu.upc.dsa.models.Muestra_Procesada;
import edu.upc.dsa.models.Persona;
import edu.upc.dsa.models.Lab;
import org.apache.log4j.Logger;

public class Covid19ManagerImpl implements Covid19Manager{

    private static Covid19ManagerImpl manager; /* SINGLETONE*/

    static final Logger logger = Logger.getLogger(Covid19ManagerImpl.class.getName());

    HashMap<String, Persona> personas;
    List<Lab> laboratorios;
    Queue<Muestra> muestras;
    List<Muestra_Procesada> muestras_procesadas;

    private Covid19ManagerImpl(){ //SINGLETONE

        this.personas = new HashMap<String, Persona>();
        this.laboratorios  = new LinkedList<Lab>();
        this.muestras_procesadas = new LinkedList<Muestra_Procesada>();

    }

    public static Covid19ManagerImpl getInstance()  //Singletone, puerta de entrada a la instancia
    {
        if (manager==null) manager = new Covid19ManagerImpl();
        return manager;

    }

    @Override
    public void addPersona(String id, String nombre, String apellidos, String edad, String valoracion) {
        //Creo a una persona
        Persona persona_nueva = new Persona(nombre, apellidos, edad, valoracion);
        this.personas.put(id, persona_nueva);
        logger.info("Identificador de la persona a agregar: "+ id);
    }

    @Override
    public void addLab(String id) {
        Lab lab_nuevo = new Lab(id);
        this.laboratorios.add(lab_nuevo);
        logger.info("se han añadido el lab con id: " + id);
    }

    @Override
    public void ExtraerMuestra(String id, String idClinica, String idUsuario, String date, String lab) {
        Muestra muestra_nueva = new Muestra(id, idClinica, idUsuario, date, lab);
        this.muestras.add(muestra_nueva); //Enviamos la muestra a la cola
    }


    public void ProcesarMuestra(String resultado, String comentario) {
        Muestra m =this.muestras.peek();
        //No he sabido añadir los datos de la muestra antes de procesar a los datos de
        //la muestra procesada
        Muestra_Procesada nueva_muestra_procesada = new Muestra_Procesada(resultado,comentario);

        //ME HE QUEDADO ATASCADO AQUÍ, ME HA DADO UN ERROR QUE NO HE SABIDO RESOLVER
        this.muestras_procesadas.setMuestras_procesadas(nueva_muestra_procesada);

    }

    @Override
    public List<Muestra> findAll() {
        return null;
    }

}
